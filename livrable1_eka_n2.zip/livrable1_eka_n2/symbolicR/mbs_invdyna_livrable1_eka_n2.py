#
#	MBsysTran - Release 8.1
#
#	Copyright 
#	Universite catholique de Louvain (UCLouvain) 
#	Mechatronic, Electrical Energy, and Dynamic systems (MEED Division) 
#	2, Place du Levant
#	1348 Louvain-la-Neuve 
#	Belgium 
#
#	http://www.robotran.be 
#
#	==> Generation Date: Tue Feb 20 12:17:55 2024
#
#	==> Project name: livrable1_eka_n2
#
#	==> Number of joints: 3
#
#	==> Function: F2 - Recursive Inverse Dynamics of tree-like MBS
#
#	==> Git hash: 8f46effdc05c898000a15b4c4dfc8f70efce4fc0
#

from math import sin, cos

def invdyna(phi,s,tsim):
    Qq = phi  # compatibility with symbolic generation
    q = s.q
    qd = s.qd
    qdd = s.qdd
 
# Trigonometric functions

    S1 = sin(q[1])
    C1 = cos(q[1])
    S2 = sin(q[2])
    C2 = cos(q[2])
    S3 = sin(q[3])
    C3 = cos(q[3])
 
# Augmented Joint Position Vectors

 
# Forward Kinematics

    BS91 = -qd[1]*qd[1]
    ALPHA11 = s.g[3]*S1
    ALPHA31 = -s.g[3]*C1
    OM22 = qd[1]+qd[2]
    OMp22 = qdd[1]+qdd[2]
    BS92 = -OM22*OM22
    ALPHA12 = C2*(ALPHA11+qdd[1]*s.dpt[3,1])-S2*(ALPHA31+BS91*s.dpt[3,1])
    ALPHA32 = C2*(ALPHA31+BS91*s.dpt[3,1])+S2*(ALPHA11+qdd[1]*s.dpt[3,1])
    OMp23 = qdd[3]+OMp22
    ALPHA13 = C3*(ALPHA12+OMp22*s.dpt[3,2])-S3*(ALPHA32+BS92*s.dpt[3,2])
    ALPHA33 = C3*(ALPHA32+BS92*s.dpt[3,2])+S3*(ALPHA12+OMp22*s.dpt[3,2])
 
# Backward Dynamics

    Fs13 = -s.frc[1,3]+s.m[3]*ALPHA13
    Fs33 = -s.frc[3,3]+s.m[3]*ALPHA33
    Cq23 = -s.trq[2,3]+s.In[5,3]*OMp23
    Fs12 = -s.frc[1,2]+s.m[2]*ALPHA12
    Fs32 = -s.frc[3,2]+s.m[2]*ALPHA32
    Fq12 = Fs12+Fs13*C3+Fs33*S3
    Fq32 = Fs32-Fs13*S3+Fs33*C3
    Cq22 = -s.trq[2,2]+Cq23+s.In[5,2]*OMp22+s.dpt[3,2]*(Fs13*C3+Fs33*S3)
    Cq21 = -s.trq[2,1]+Cq22+qdd[1]*s.In[5,1]+s.dpt[3,1]*(Fq12*C2+Fq32*S2)
 
# Symbolic model output

    Qq[1] = Cq21
    Qq[2] = Cq22
    Qq[3] = Cq23

# Number of continuation lines = 0



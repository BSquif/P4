#
#	MBsysTran - Release 8.1
#
#	Copyright 
#	Universite catholique de Louvain (UCLouvain) 
#	Mechatronic, Electrical Energy, and Dynamic systems (MEED Division) 
#	2, Place du Levant
#	1348 Louvain-la-Neuve 
#	Belgium 
#
#	http://www.robotran.be 
#
#	==> Generation Date: Thu Feb 22 15:29:27 2024
#
#	==> Project name: livrable1_eka_n2
#
#	==> Number of joints: 3
#
#	==> Function: F6 - Sensors Kinematics
#
#	==> Git hash: 8f46effdc05c898000a15b4c4dfc8f70efce4fc0
#

from math import sin, cos, sqrt

def sensor(sens, s, isens):
  q = s.q
  qd = s.qd
  qdd = s.qdd

  dpt = s.dpt
 
# Trigonometric functions

  S1 = sin(q[1])
  C1 = cos(q[1])
  S2 = sin(q[2])
  C2 = cos(q[2])
  S3 = sin(q[3])
  C3 = cos(q[3])
 
# Augmented Joint Position Vectors

 
# Sensor Kinematics


  if (isens == 1): 

    sens.P[1] = 0
    sens.P[2] = 0
    sens.P[3] = 0
    sens.R[1,1] = C1
    sens.R[1,3] = -S1
    sens.R[2,2] = (1.0)
    sens.R[3,1] = S1
    sens.R[3,3] = C1
    sens.V[1] = 0
    sens.V[2] = 0
    sens.V[3] = 0
    sens.OM[1] = 0
    sens.OM[2] = qd[1]
    sens.OM[3] = 0
    sens.J[5,1] = (1.0)
    sens.A[1] = 0
    sens.A[2] = 0
    sens.A[3] = 0
    sens.OMP[1] = 0
    sens.OMP[2] = qdd[1]
    sens.OMP[3] = 0

  if (isens == 2): 

    ROcp2_12 = C1*C2-S1*S2
    ROcp2_32 = -C1*S2-S1*C2
    ROcp2_72 = C1*S2+S1*C2
    ROcp2_92 = C1*C2-S1*S2
    RLcp2_12 = s.dpt[3,1]*S1
    RLcp2_32 = s.dpt[3,1]*C1
    OMcp2_22 = qd[1]+qd[2]
    ORcp2_12 = RLcp2_32*qd[1]
    ORcp2_32 = -RLcp2_12*qd[1]
    OPcp2_22 = qdd[1]+qdd[2]
    ACcp2_12 = ORcp2_32*qd[1]+RLcp2_32*qdd[1]
    ACcp2_32 = -ORcp2_12*qd[1]-RLcp2_12*qdd[1]
    sens.P[1] = RLcp2_12
    sens.P[2] = 0
    sens.P[3] = RLcp2_32
    sens.R[1,1] = ROcp2_12
    sens.R[1,3] = ROcp2_32
    sens.R[2,2] = (1.0)
    sens.R[3,1] = ROcp2_72
    sens.R[3,3] = ROcp2_92
    sens.V[1] = ORcp2_12
    sens.V[2] = 0
    sens.V[3] = ORcp2_32
    sens.OM[1] = 0
    sens.OM[2] = OMcp2_22
    sens.OM[3] = 0
    sens.J[1,1] = RLcp2_32
    sens.J[3,1] = -RLcp2_12
    sens.J[5,1] = (1.0)
    sens.J[5,2] = (1.0)
    sens.A[1] = ACcp2_12
    sens.A[2] = 0
    sens.A[3] = ACcp2_32
    sens.OMP[1] = 0
    sens.OMP[2] = OPcp2_22
    sens.OMP[3] = 0

  if (isens == 3): 

    ROcp3_12 = C1*C2-S1*S2
    ROcp3_32 = -C1*S2-S1*C2
    ROcp3_72 = C1*S2+S1*C2
    ROcp3_92 = C1*C2-S1*S2
    ROcp3_13 = ROcp3_12*C3-ROcp3_72*S3
    ROcp3_33 = ROcp3_32*C3-ROcp3_92*S3
    ROcp3_73 = ROcp3_12*S3+ROcp3_72*C3
    ROcp3_93 = ROcp3_32*S3+ROcp3_92*C3
    RLcp3_12 = s.dpt[3,1]*S1
    RLcp3_32 = s.dpt[3,1]*C1
    OMcp3_22 = qd[1]+qd[2]
    ORcp3_12 = RLcp3_32*qd[1]
    ORcp3_32 = -RLcp3_12*qd[1]
    OPcp3_22 = qdd[1]+qdd[2]
    ACcp3_12 = ORcp3_32*qd[1]+RLcp3_32*qdd[1]
    ACcp3_32 = -ORcp3_12*qd[1]-RLcp3_12*qdd[1]
    RLcp3_13 = ROcp3_72*s.dpt[3,2]
    RLcp3_33 = ROcp3_92*s.dpt[3,2]
    POcp3_13 = RLcp3_12+RLcp3_13
    POcp3_33 = RLcp3_32+RLcp3_33
    JTcp3_13_1 = RLcp3_32+RLcp3_33
    JTcp3_33_1 = -RLcp3_12-RLcp3_13
    OMcp3_23 = OMcp3_22+qd[3]
    ORcp3_13 = OMcp3_22*RLcp3_33
    ORcp3_33 = -OMcp3_22*RLcp3_13
    VIcp3_13 = ORcp3_12+ORcp3_13
    VIcp3_33 = ORcp3_32+ORcp3_33
    OPcp3_23 = OPcp3_22+qdd[3]
    ACcp3_13 = ACcp3_12+OMcp3_22*ORcp3_33+OPcp3_22*RLcp3_33
    ACcp3_33 = ACcp3_32-OMcp3_22*ORcp3_13-OPcp3_22*RLcp3_13
    sens.P[1] = POcp3_13
    sens.P[2] = 0
    sens.P[3] = POcp3_33
    sens.R[1,1] = ROcp3_13
    sens.R[1,3] = ROcp3_33
    sens.R[2,2] = (1.0)
    sens.R[3,1] = ROcp3_73
    sens.R[3,3] = ROcp3_93
    sens.V[1] = VIcp3_13
    sens.V[2] = 0
    sens.V[3] = VIcp3_33
    sens.OM[1] = 0
    sens.OM[2] = OMcp3_23
    sens.OM[3] = 0
    sens.J[1,1] = JTcp3_13_1
    sens.J[1,2] = RLcp3_33
    sens.J[3,1] = JTcp3_33_1
    sens.J[3,2] = -RLcp3_13
    sens.J[5,1] = (1.0)
    sens.J[5,2] = (1.0)
    sens.J[5,3] = (1.0)
    sens.A[1] = ACcp3_13
    sens.A[2] = 0
    sens.A[3] = ACcp3_33
    sens.OMP[1] = 0
    sens.OMP[2] = OPcp3_23
    sens.OMP[3] = 0

 


# Number of continuation lines = 0



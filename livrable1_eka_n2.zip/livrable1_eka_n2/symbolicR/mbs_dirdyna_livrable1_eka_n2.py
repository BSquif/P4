#
#	MBsysTran - Release 8.1
#
#	Copyright 
#	Universite catholique de Louvain (UCLouvain) 
#	Mechatronic, Electrical Energy, and Dynamic systems (MEED Division) 
#	2, Place du Levant
#	1348 Louvain-la-Neuve 
#	Belgium 
#
#	http://www.robotran.be 
#
#	==> Generation Date: Thu Feb 22 15:29:27 2024
#
#	==> Project name: livrable1_eka_n2
#
#	==> Number of joints: 3
#
#	==> Function: F1 - Recursive Direct Dynamics of tree-like MBS
#
#	==> Git hash: 8f46effdc05c898000a15b4c4dfc8f70efce4fc0
#

from math import sin, cos

def dirdyna(M, c, s, tsim):
    q = s.q
    qd = s.qd
 
# Trigonometric functions

    S1 = sin(q[1])
    C1 = cos(q[1])
    S2 = sin(q[2])
    C2 = cos(q[2])
    S3 = sin(q[3])
    C3 = cos(q[3])
 
# Forward Kinematics

    BS91 = -qd[1]*qd[1]
    AF11 = s.g[3]*S1
    AF31 = -s.g[3]*C1
    OM22 = qd[1]+qd[2]
    BS92 = -OM22*OM22
    AF12 = AF11*C2-S2*(AF31+BS91*s.dpt[3,1])
    AF32 = AF11*S2+C2*(AF31+BS91*s.dpt[3,1])
    AM12_1 = s.dpt[3,1]*C2
    AM32_1 = s.dpt[3,1]*S2
    AF13 = AF12*C3-S3*(AF32+BS92*s.dpt[3,2])
    AF33 = AF12*S3+C3*(AF32+BS92*s.dpt[3,2])
    AM13_1 = -AM32_1*S3+C3*(AM12_1+s.dpt[3,2])
    AM33_1 = AM32_1*C3+S3*(AM12_1+s.dpt[3,2])
    AM13_2 = s.dpt[3,2]*C3
    AM33_2 = s.dpt[3,2]*S3
 
# Backward Dynamics

    FA13 = -s.frc[1,3]+s.m[3]*AF13
    FA33 = -s.frc[3,3]+s.m[3]*AF33
    FB13_1 = s.m[3]*AM13_1
    FB33_1 = s.m[3]*AM33_1
    FB13_2 = s.m[3]*AM13_2
    FB33_2 = s.m[3]*AM33_2
    FA12 = -s.frc[1,2]+s.m[2]*AF12
    FA32 = -s.frc[3,2]+s.m[2]*AF32
    FF12 = FA12+FA13*C3+FA33*S3
    FF32 = FA32-FA13*S3+FA33*C3
    CF22 = -s.trq[2,2]-s.trq[2,3]+s.dpt[3,2]*(FA13*C3+FA33*S3)
    FB12_1 = s.m[2]*AM12_1
    FB32_1 = s.m[2]*AM32_1
    FM12_1 = FB12_1+FB13_1*C3+FB33_1*S3
    FM32_1 = FB32_1-FB13_1*S3+FB33_1*C3
    CM22_1 = s.In[5,2]+s.In[5,3]+s.dpt[3,2]*(FB13_1*C3+FB33_1*S3)
    CM22_2 = s.In[5,2]+s.In[5,3]+s.dpt[3,2]*(FB13_2*C3+FB33_2*S3)
    CF21 = -s.trq[2,1]+CF22+s.dpt[3,1]*(FF12*C2+FF32*S2)
    CM21_1 = s.In[5,1]+CM22_1+s.dpt[3,1]*(FM12_1*C2+FM32_1*S2)
 
# Symbolic model output

    c[1] = CF21
    c[2] = CF22
    c[3] = -s.trq[2,3]
    M[1,1] = CM21_1
    M[1,2] = CM22_1
    M[1,3] = s.In[5,3]
    M[2,1] = CM22_1
    M[2,2] = CM22_2
    M[2,3] = s.In[5,3]
    M[3,1] = s.In[5,3]
    M[3,2] = s.In[5,3]
    M[3,3] = s.In[5,3]

# Number of continuation lines = 0



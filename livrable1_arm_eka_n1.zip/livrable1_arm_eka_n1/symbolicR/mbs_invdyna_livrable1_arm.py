#
#	MBsysTran - Release 8.1
#
#	Copyright 
#	Universite catholique de Louvain (UCLouvain) 
#	Mechatronic, Electrical Energy, and Dynamic systems (MEED Division) 
#	2, Place du Levant
#	1348 Louvain-la-Neuve 
#	Belgium 
#
#	http://www.robotran.be 
#
#	==> Generation Date: Sun Feb 18 16:52:00 2024
#
#	==> Project name: livrable1_arm
#
#	==> Number of joints: 2
#
#	==> Function: F2 - Recursive Inverse Dynamics of tree-like MBS
#
#	==> Git hash: 8f46effdc05c898000a15b4c4dfc8f70efce4fc0
#

from math import sin, cos

def invdyna(phi,s,tsim):
    Qq = phi  # compatibility with symbolic generation
    q = s.q
    qd = s.qd
    qdd = s.qdd
 
# Trigonometric functions

    S1 = sin(q[1])
    C1 = cos(q[1])
    S2 = sin(q[2])
    C2 = cos(q[2])
 
# Augmented Joint Position Vectors

 
# Forward Kinematics

    BS91 = -qd[1]*qd[1]
    ALPHA11 = s.g[3]*S1
    ALPHA31 = -s.g[3]*C1
    OMp22 = qdd[1]+qdd[2]
    ALPHA12 = C2*(ALPHA11+qdd[1]*s.dpt[3,1])-S2*(ALPHA31+BS91*s.dpt[3,1])
    ALPHA32 = C2*(ALPHA31+BS91*s.dpt[3,1])+S2*(ALPHA11+qdd[1]*s.dpt[3,1])
 
# Backward Dynamics

    Fs12 = -s.frc[1,2]+s.m[2]*ALPHA12
    Fs32 = -s.frc[3,2]+s.m[2]*ALPHA32
    Cq22 = -s.trq[2,2]+s.In[5,2]*OMp22
    Cq21 = -s.trq[2,1]+Cq22+qdd[1]*s.In[5,1]+s.dpt[3,1]*(Fs12*C2+Fs32*S2)
 
# Symbolic model output

    Qq[1] = Cq21
    Qq[2] = Cq22

# Number of continuation lines = 0



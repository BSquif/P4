#
#	MBsysTran - Release 8.1
#
#	Copyright 
#	Universite catholique de Louvain (UCLouvain) 
#	Mechatronic, Electrical Energy, and Dynamic systems (MEED Division) 
#	2, Place du Levant
#	1348 Louvain-la-Neuve 
#	Belgium 
#
#	http://www.robotran.be 
#
#	==> Generation Date: Sun Feb 18 16:52:00 2024
#
#	==> Project name: livrable1_arm
#
#	==> Number of joints: 2
#
#	==> Function: F6 - Sensors Kinematics
#
#	==> Git hash: 8f46effdc05c898000a15b4c4dfc8f70efce4fc0
#

from math import sin, cos, sqrt

def sensor(sens, s, isens):
  q = s.q
  qd = s.qd
  qdd = s.qdd

  dpt = s.dpt
 
# Trigonometric functions

  S1 = sin(q[1])
  C1 = cos(q[1])
  S2 = sin(q[2])
  C2 = cos(q[2])
 
# Augmented Joint Position Vectors

 
# Sensor Kinematics


  if (isens == 1): 

    sens.P[1] = 0
    sens.P[2] = 0
    sens.P[3] = 0
    sens.R[1,1] = C1
    sens.R[1,3] = -S1
    sens.R[2,2] = (1.0)
    sens.R[3,1] = S1
    sens.R[3,3] = C1
    sens.V[1] = 0
    sens.V[2] = 0
    sens.V[3] = 0
    sens.OM[1] = 0
    sens.OM[2] = qd[1]
    sens.OM[3] = 0
    sens.J[5,1] = (1.0)
    sens.A[1] = 0
    sens.A[2] = 0
    sens.A[3] = 0
    sens.OMP[1] = 0
    sens.OMP[2] = qdd[1]
    sens.OMP[3] = 0

  if (isens == 2): 

    ROcp2_12 = C1*C2-S1*S2
    ROcp2_32 = -C1*S2-S1*C2
    ROcp2_72 = C1*S2+S1*C2
    ROcp2_92 = C1*C2-S1*S2
    RLcp2_12 = s.dpt[3,1]*S1
    RLcp2_32 = s.dpt[3,1]*C1
    OMcp2_22 = qd[1]+qd[2]
    ORcp2_12 = RLcp2_32*qd[1]
    ORcp2_32 = -RLcp2_12*qd[1]
    OPcp2_22 = qdd[1]+qdd[2]
    ACcp2_12 = ORcp2_32*qd[1]+RLcp2_32*qdd[1]
    ACcp2_32 = -ORcp2_12*qd[1]-RLcp2_12*qdd[1]
    sens.P[1] = RLcp2_12
    sens.P[2] = 0
    sens.P[3] = RLcp2_32
    sens.R[1,1] = ROcp2_12
    sens.R[1,3] = ROcp2_32
    sens.R[2,2] = (1.0)
    sens.R[3,1] = ROcp2_72
    sens.R[3,3] = ROcp2_92
    sens.V[1] = ORcp2_12
    sens.V[2] = 0
    sens.V[3] = ORcp2_32
    sens.OM[1] = 0
    sens.OM[2] = OMcp2_22
    sens.OM[3] = 0
    sens.J[1,1] = RLcp2_32
    sens.J[3,1] = -RLcp2_12
    sens.J[5,1] = (1.0)
    sens.J[5,2] = (1.0)
    sens.A[1] = ACcp2_12
    sens.A[2] = 0
    sens.A[3] = ACcp2_32
    sens.OMP[1] = 0
    sens.OMP[2] = OPcp2_22
    sens.OMP[3] = 0

 


# Number of continuation lines = 0


